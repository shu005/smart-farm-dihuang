"use client"

import { useState } from "react"
import { Plus } from "lucide-react"

interface AddTaskInputProps {
  onAdd: (text: string) => void
}

export function AddTaskInput({ onAdd }: AddTaskInputProps) {
  const [value, setValue] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const trimmed = value.trim()
    if (trimmed) {
      onAdd(trimmed)
      setValue("")
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex items-center gap-3">
      <input
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Add a new task..."
        className="h-11 flex-1 rounded-xl border border-input bg-card px-4 text-sm text-foreground placeholder:text-muted-foreground shadow-sm outline-none transition-all duration-200 focus:border-ring focus:ring-2 focus:ring-ring/20"
        aria-label="新任务输入框"
      />
      <button
        type="submit"
        className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm transition-all duration-200 hover:bg-primary/90 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label="添加新任务"
      >
        <Plus className="size-5" strokeWidth={2.5} />
      </button>
    </form>
  )
}
