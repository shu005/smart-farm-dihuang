"use client"

import { useState } from "react"
import { TaskItem, type Task } from "@/components/task-item"
import { AddTaskInput } from "@/components/add-task-input"
import { ListChecks } from "lucide-react"

const initialTasks: Task[] = [
  { id: "1", text: "阅读AI开发文档", completed: false },
  { id: "2", text: "喝杯水", completed: true },
  { id: "3", text: "给绿植浇水", completed: false },
]

export function TaskList() {
  const [tasks, setTasks] = useState<Task[]>(initialTasks)

  const handleAdd = (text: string) => {
    const newTask: Task = {
      id: Date.now().toString(),
      text,
      completed: false,
    }
    setTasks((prev) => [newTask, ...prev])
  }

  const handleToggle = (id: string) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    )
  }

  const handleDelete = (id: string) => {
    setTasks((prev) => prev.filter((task) => task.id !== id))
  }

  const completedCount = tasks.filter((t) => t.completed).length

  return (
    <div className="flex min-h-svh items-start justify-center bg-background px-4 py-12 md:items-center md:py-0">
      <div className="w-full max-w-md">
        {/* Header */}
        <header className="mb-8">
          <div className="flex items-center gap-3">
            <ListChecks className="size-8 text-foreground" strokeWidth={1.8} />
            <h1 className="text-3xl font-bold tracking-tight text-foreground">
              My Tasks
            </h1>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            {tasks.length > 0
              ? `${completedCount} / ${tasks.length} 项已完成`
              : "暂无任务，快来添加吧"}
          </p>
        </header>

        {/* Input */}
        <div className="mb-6">
          <AddTaskInput onAdd={handleAdd} />
        </div>

        {/* Task List */}
        <div className="flex flex-col gap-3" role="list" aria-label="任务列表">
          {tasks.map((task) => (
            <div key={task.id} role="listitem">
              <TaskItem
                task={task}
                onToggle={handleToggle}
                onDelete={handleDelete}
              />
            </div>
          ))}
        </div>

        {tasks.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="mb-4 flex size-16 items-center justify-center rounded-2xl bg-muted">
              <ListChecks className="size-8 text-muted-foreground" strokeWidth={1.5} />
            </div>
            <p className="text-sm font-medium text-muted-foreground">
              还没有任务
            </p>
            <p className="mt-1 text-xs text-muted-foreground/70">
              在上方输入框中添加你的第一个任务
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
