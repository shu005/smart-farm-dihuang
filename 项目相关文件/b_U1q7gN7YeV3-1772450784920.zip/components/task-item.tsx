"use client"

import { Checkbox } from "@/components/ui/checkbox"
import { Trash2 } from "lucide-react"
import { cn } from "@/lib/utils"

export interface Task {
  id: string
  text: string
  completed: boolean
}

interface TaskItemProps {
  task: Task
  onToggle: (id: string) => void
  onDelete: (id: string) => void
}

export function TaskItem({ task, onToggle, onDelete }: TaskItemProps) {
  return (
    <div
      className={cn(
        "group flex items-center gap-4 rounded-xl bg-card px-4 py-3.5 shadow-sm transition-all duration-200 hover:shadow-md",
        task.completed && "opacity-80"
      )}
    >
      <Checkbox
        checked={task.completed}
        onCheckedChange={() => onToggle(task.id)}
        className="size-5 rounded-full border-2 border-muted-foreground/30 data-[state=checked]:border-primary data-[state=checked]:bg-primary"
        aria-label={task.completed ? `将「${task.text}」标记为未完成` : `将「${task.text}」标记为已完成`}
      />
      <span
        className={cn(
          "flex-1 text-sm font-medium leading-relaxed text-card-foreground transition-all duration-200",
          task.completed && "text-muted-foreground line-through"
        )}
      >
        {task.text}
      </span>
      <button
        onClick={() => onDelete(task.id)}
        className="flex shrink-0 items-center justify-center rounded-lg p-1.5 text-destructive/60 opacity-0 transition-all duration-200 hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100 focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label={`删除任务「${task.text}」`}
      >
        <Trash2 className="size-4" />
      </button>
    </div>
  )
}
