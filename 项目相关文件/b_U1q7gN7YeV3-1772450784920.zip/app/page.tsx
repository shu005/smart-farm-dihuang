import { TaskList } from "@/components/task-list"

export default function Page() {
  return (
    <main>
      <TaskList />
    </main>
  )
}
